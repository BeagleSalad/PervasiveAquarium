import React from "react";
import AquariumThermostat from "./AquariumThermostat.js"; // Adjust the path if necessary

const App = () => {
  return (
    <div>
      <AquariumThermostat />
    </div>
  );
};

export default App;